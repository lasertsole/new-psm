package com.psm.daemon_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaemonBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
